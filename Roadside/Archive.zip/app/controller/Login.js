Ext.define('Roadside.controller.Login', {
	extend: 'Ext.app.Controller',

	config: {
		refs: {			
			loginView: 'loginview',
			mainMenuView: 'mainMenuView',
			mainProfileView: 'mainProfileView',
			maintabpanel: 'maintabpanel',
			profileForm: 'mainProfileView #profileForm'

		},
		control: {			
			loginView: {
				signInCommand: 'onSignInCommand',
			//	guestClickCommand: 'guestClickCommand',				
			},
			mainMenuView: {
				onSignOffCommand: 'onSignOffCommand'
			},
			mainProfileView: {
				profileSubmitCommand: 'profileSubmitCommand',				
			}
		}
	},

	// Session token

	sessionToken: null,
	
	// Transitions
	getSlideLeftTransition: function () {
		return { type: 'slide', direction: 'left' };
	},

	getSlideRightTransition: function () {
		return { type: 'slide', direction: 'right' };
	},
/*
	guestClickCommand: function (view) {

		console.log('guestClickCommand begin!!!');

		var me = this,
		maintabpanel = me.getMaintabpanel();
		loginView = me.getLoginView();
		mainProfileView = me.getMainProfileView();
		if(!mainProfileView)
		{
			mainProfileView = Ext.create('Roadside.view.MainProfile');	
		}
		
		var userStore = Ext.getStore('userstore');
		userStore.load();
		
		var item = userStore.getAt(0);
		console.log('userStore storeId '+item);
		 userStore.each(function (record) {
                    console.log(record.getData());
                });
		var userStore = Ext.getStore('userstore');
                    userStore.load(function(records, operation, success)
                    {
                        if(success)
                        {
                            var record = userStore.first();
                            console.log('record ==== '+record.getData().username);                      
                           mainProfileView.setRecord(record);
                        }
                       
                    });
		
	loginView.push(mainProfileView);
	}, */

	profileSubmitCommand:function (view) {

		var form = this.getProfileForm();
		var values = form.getValues();
		console.log('profileSubmitCommand Username: ' + values + '\n' + 'NAME: ' + values.name);
		var usr = Ext.create('Roadside.model.UserProfile',{
			username: values.name,
			age: '30',
			email:values.email
		});

		var userStore = Ext.getStore('userstore');
		userStore.removeAll();
		userStore.add(usr);
		userStore.sync();
		console.log('profileSubmitCommand getCount: ' +userStore.getCount());
	

		form.setRecord(usr);
		  // Mask the form
                            form.setMasked({
                                xtype: 'loadmask',
                                message: 'Saving...'
                            });

                            // Put it inside a timeout so it feels like it is going to a server.
                            setTimeout(function() {
                                if (form.user) {
                                    // Call the updateRecord method of formpanel with the user record instance. This will update the user record
                                    // with the latest values.
                                    form.updateRecord(usr, true);
                                }

                                // Unmask the formpanel
                                form.setMasked(false);
                            }, 1000);
                                
		

	},

	profileHome: function () {
		console.log('mainProfileView in.');	
		Ext.Viewport.remove(this.loginview); 
		Ext.Viewport.getComponent(0).setActiveItem(0);
	
		Ext.Viewport.getComponent(0).animateActiveItem({ xtype : 'mainProfileView'}, {type: 'slide', direction: 'left'});
	
		console.log("mainProfileView screen!");
	
	},

	
	onSignInCommand: function (view, username, password) {

		console.log('Username: ' + username + '\n' + 'Password: ' + password);
		// var db = window.openDatabase("test", "1.0", "Test DB", 1000000);
		//console.log('db: ' + db );
		var me = this,		
		maintabpanel = me.getMaintabpanel();
		loginView = me.getLoginView();
		mainProfileView = me.getMainProfileView();
		
		if(!mainProfileView)
		{
			mainProfileView = Ext.create('Roadside.view.MainProfile');	
		}
		
		
		if (username.length === 0 || password.length === 0) {

			loginView.showSignInFailedMessage('Please enter your username and password.');
			return;
		}

		loginView.setMasked({
			xtype: 'loadmask',
			message: 'Signing In...'
		});

		if(username == 'test')
		{
			
			me.signInSuccess();     //Just simulating success.
		}
		else{
			me.singInFailure('Login failed. Please try again later.');
		}

/*
Ext.Ajax.request({
url: '../../services/login.ashx',
method: 'post',
params: {
user: username,
pwd: password
},
success: function (response) {

var loginResponse = Ext.JSON.decode(response.responseText);

if (loginResponse.success === "true") {
// The server will send a token that can be used throughout the app to confirm that the user is authenticated.
me.sessionToken = loginResponse.sessionToken;
me.signInSuccess();     //Just simulating success.
} else {
me.singInFailure(loginResponse.message);
}
},
failure: function (response) {
me.sessionToken = null;
me.singInFailure('Login failed. Please try again later.');
}
});
*/
},





signInSuccess: function () {
	console.log('Signed in.');
	var loginView = this.getLoginView();
	//Ext.Viewport.getComponent(0).setActiveItem(1);

	//Ext.Viewport.getComp(0).animateActiveItem({ xtype : 'mainMenuView'}, {type: 'slide', direction: 'left'});
	loginView.push(this.mainMenuView);

	console.log("mainMenuView screen!");

},

singInFailure: function (message) {
	var loginView = this.getLoginView();
	loginView.showSignInFailedMessage(message);
	loginView.setMasked(false);
},

onSignOffCommand: function () {
	console.log("Login Controller :  onSignOffCommand!");
	var me = this;

	/* Ext.Ajax.request({
	url: '../../services/logoff.ashx',
	method: 'post',
	params: {
	sessionToken: me.sessionToken
	},
	success: function (response) {

	// TODO: You need to handle this condition.
	},
	failure: function (response) {

	// TODO: You need to handle this condition.
	}
	});
	*/
	Ext.Viewport.animateActiveItem(this.getLoginView(), this.getSlideRightTransition());
},
// Base Class functions.
launch: function () {
	this.callParent(arguments);
	
	console.log("launch");
	//Ext.Msg.alert('in onDeviceReady method.................android = '+Ext.is.Android +'   IOS== '+Ext.is.iOS);
	console.log('Login Controller : Device Model: '    + device.model    + '<br />' +
                            'Device Cordova: '  + device.cordova  + '<br />' +
                            'Device Platform: ' + device.platform + '<br />' +
                            'Device UUID: '     + device.uuid     + '<br />' +
                            'Device Version: '  + device.version  + '<br />');
                            
},
init: function () {
	this.callParent(arguments);
	console.log("init");
	//this.onOverCommand();
}

});
